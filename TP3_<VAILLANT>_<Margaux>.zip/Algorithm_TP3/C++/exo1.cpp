#include "lib/mainwindow.h"
#include <QApplication>
#include <time.h>

MainWindow* w = nullptr;
using std::size_t;

int binarySearch(Array& array, int toSearch)
{
        int debut=0;
        int fin= (int)array.size();
        int i;

        while(debut<fin){
            i=(debut+fin)/2;

            if(array[i] > toSearch){
                fin=i;
            }
            if(array[i] < toSearch){
                debut=i+1;
            }
            if(array[i] == toSearch){
                return i;
            }
        }
        return -1;
}

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	MainWindow::instruction_duration = 500;
	w = new BinarySearchWindow(binarySearch);
	w->show();

	return a.exec();
}
