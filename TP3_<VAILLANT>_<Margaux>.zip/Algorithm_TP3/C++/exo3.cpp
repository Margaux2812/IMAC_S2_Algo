#include "lib/mainwindow.h"
#include <QApplication>
#include <time.h>
#include <stdio.h>
#define max(a, b) ((a) > (b) ? (a) : (b))

MainWindow* w = nullptr;
using std::size_t;

struct BinarySearchTree : public BinaryTree
{
	BinarySearchTree(int value=0) : BinaryTree(value) {}
	virtual ~BinarySearchTree() {}

	void insertNumber(int value)
	{
            if(this->value >= value){
                if(this->left != NULL){
                    this->left->insertNumber(value);
                }else{
                    this->left = createNode(value);
                }
            }else{
                if(this->right != NULL){
                    this->right->insertNumber(value);
                }else{
                    this->right = createNode(value);
                }
            }
	}

	uint height() const
	{
        if(this != NULL){
            uint countL = 0, countR = 0;
            if(this->left != NULL){
                countL = this->left->height();
            }
            if(this->right != NULL){
                countR = this->right->height();
            }

            return 1+max(countL, countR);
        }else{
            return 0;
        }

	}

	uint nodesCount() const
	{
        if(this != NULL){
            uint countL = 0, countR = 0;
            if(this->left != NULL){
                countL = this->left->nodesCount();
            }
            if(this->right != NULL){
                countR = this->right->nodesCount();
            }
            return 1+countL+countR;
		}else{
            return 0;
		}
	}

	bool isLeaf() const
	{
        if(this == NULL){
            return false;
        }
        if(this->left == NULL && this->right == NULL){
            return true;
        }
        return false;
    }

	void allLeaves(Node* leaves[], uint& leavesCount)
	{
        if(this != NULL){
            //Si c'est une feuille
            if(this->isLeaf()){
                leaves[leavesCount] = this;
                leavesCount++;
            }else{
                if(this->left != NULL)
                    this->left->allLeaves(leaves, leavesCount);
                if(this->right != NULL)
                    this->right->allLeaves(leaves, leavesCount);
            }
        }

	}

	void inorderTravel(Node* nodes[], uint& nodesCount)
	{
        if(this != NULL){
            if(this->left != NULL){
                this->left->inorderTravel(nodes, nodesCount);
            }

            nodes[nodesCount] = this;
            nodesCount++;
            if(this->right != NULL){
                this->right->inorderTravel(nodes, nodesCount);
            }

        }

	}

	void preorderTravel(Node* nodes[], uint& nodesCount)
	{
        if(this != NULL){
            nodes[nodesCount] = this;
            nodesCount++;
            if(this->left != NULL){
                this->left->preorderTravel(nodes, nodesCount);
            }

            if(this->right != NULL){
                this->right->preorderTravel(nodes, nodesCount);
            }
        }
	}

	void postorderTravel(Node* nodes[], uint& nodesCount)
	{
        if(this != NULL){
            if(this->left != NULL){
                this->left->postorderTravel(nodes, nodesCount);
            }

            if(this->right != NULL){
                this->right->postorderTravel(nodes, nodesCount);
            }
            nodes[nodesCount] = this;
            nodesCount++;

        }
	}

	Node* find(int value)
	{
        Node *temp = this;

        while (temp != NULL){
            if (temp->value == value)
                break;

            if (value > temp->value)
               temp = temp->right;
            else{                 //  <--- Put this 'else' here
                if (value < temp->value)
                    temp = temp->left;
            }
       }

       if (temp == NULL)
        return NULL;

       if (temp->value == value)
            return temp;

       return NULL;
   }
};

Node* createNode(int value) {
	return new BinarySearchTree(value);
}

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
    MainWindow::instruction_duration = 40;
	BinarySearchTree bst;
	w = new BinarySearchTreeWindow(bst);
	w->show();

	return a.exec();
}
