#include "lib/mainwindow.h"
#include <QApplication>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>

MainWindow* w = nullptr;
using std::size_t;

void binarySearchAll(Array& array, int toSearch, int& indexMin, int& indexMax)
{
    int debut=0;
    int fin= (int)array.size();
    int i;
    indexMin = indexMax = -1;

    while(debut<fin){
        i=(debut+fin)/2;

        if(array[i] > toSearch){
            fin=i;
        }
        if(array[i] < toSearch){
            debut=i+1;
        }
        if(array[i] == toSearch){
            indexMin=indexMax=i;
            for(int j=debut; j<fin; j++){
                if(array[j] == toSearch){
                    if(j<i)
                        indexMin=j;
                    else{
                        indexMax=j;
                    }
                }
            }
            break;
        }
    }
}

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	MainWindow::instruction_duration = 500;
	w = new BinarySearchAllWindow(binarySearchAll);
	w->show();

	return a.exec();
}
