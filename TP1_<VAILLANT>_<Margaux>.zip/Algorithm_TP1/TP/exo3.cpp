#include "lib/mainwindow.h"
#include <QApplication>
#include <time.h>

MainWindow* w=nullptr;

void bubbleSort(Array& toSort){
    int i, j;
    int size = toSort.size();
      for (i = 0; i < size; i++){
          for (j = 0; j < size-1-i; j++){
              if (toSort[j] > toSort[j+1]){
                 toSort.swap(j, j+1);
              }
          }
      }
}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
	Array::instruction_duration = 200;
	w = new MainWindow(bubbleSort, 15);
    w->show();

    return a.exec();
}
