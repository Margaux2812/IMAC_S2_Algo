#include "lib/mainwindow.h"
#include <QApplication>
#include <time.h>

MainWindow* w=nullptr;

void recursivQuickSort(Array& toSort, int size)
{
    if (size <= 1) {
        return;
    } else {

       uint pivot = toSort.get(0);
       Array lowers(size), greaters(size);
       uint sizeL = 0;
       uint sizeG = 0;

       for (uint i=1; i<size; i++) {
           if (toSort.get(i)<pivot) {
               lowers[sizeL] = toSort.get(i);
               sizeL ++;
           }
           else {
               greaters[sizeG] = toSort.get(i);
               sizeG ++;
           }
       }
       recursivQuickSort(lowers, sizeL);
       recursivQuickSort(greaters, sizeG);

       for (uint i=0; i<sizeL; i++) {
           toSort[i] = lowers[i];
       }
       toSort[sizeL] = pivot;

       for (uint i=sizeL+1; i<size; i++) {
           toSort[i] = greaters[i-sizeL-1];
       }
    }
}


void quickSort(Array& toSort){
    recursivQuickSort(toSort, toSort.size());
}



int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
	Array::instruction_duration = 200;
	w = new MainWindow(quickSort, 15);
    w->show();

    return a.exec();
}
