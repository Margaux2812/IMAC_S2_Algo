#include "lib/mainwindow.h"
#include <QApplication>
#include <time.h>

MainWindow* w=nullptr;


void insertionSort(Array& toSort){
//	Array& secondArray=w->newArray(toSort.size());
    int temp;
    for(uint i=0; i<toSort.size(); i++)
    {
        uint j=i;
        while (j >0 && toSort[j]<toSort[j-1])
        {
           temp = toSort[j];
           toSort[j]=toSort[j-1];
           toSort[j-1]=temp;
           j--;
        }
    }
}

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	Array::instruction_duration = 200;
	w = new MainWindow(insertionSort, 15);
	w->show();

	return a.exec();
}
